# Contributing

## Feature additions or bug fixes

1. [Fork the repo](https://github.com/SnailyCAD/snaily-cadv4/fork)
2. [Follow the installation guide](https://cad-docs.caspertheghost.me/docs/installations)
3. Create the feature branch (`git checkout -b my-cool-feature`)
4. Commit your changes (git commit -m "Added a cool new feature")
5. [Open a pull request](https://github.com/Dev-CasperTheGhost/snaily-cadv3/pulls)

## Translations

TODO
