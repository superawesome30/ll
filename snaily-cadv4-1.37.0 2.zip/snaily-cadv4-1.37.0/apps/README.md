# `apps` directory

This directory holds all the application state and UI

- `api/`: This directory powers SnailyCADv4's API. This processes all the incoming requests.
- `client/`: This is what you as the end user will see on the screen in the browser.
