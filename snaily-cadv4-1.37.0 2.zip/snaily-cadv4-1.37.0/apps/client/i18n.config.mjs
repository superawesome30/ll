export const i18n = {
  locales: ["en", "en-gb", "ru", "cn", "tc", "fr-FR", "de-DE", "pt-BR", "cs-CZ"],
  defaultLocale: "en",
};
