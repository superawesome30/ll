-- AlterTable
ALTER TABLE "MiscCadSettings" ADD COLUMN     "maxOfficersPerUser" INTEGER;
