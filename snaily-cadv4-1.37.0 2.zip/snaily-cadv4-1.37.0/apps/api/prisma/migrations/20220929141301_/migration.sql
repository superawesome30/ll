-- AlterTable
ALTER TABLE "Record" ADD COLUMN     "caseNumber" SERIAL NOT NULL;
