-- AlterTable
ALTER TABLE "TaxiCall" ADD COLUMN     "name" TEXT;

-- AlterTable
ALTER TABLE "TowCall" ADD COLUMN     "name" TEXT;
