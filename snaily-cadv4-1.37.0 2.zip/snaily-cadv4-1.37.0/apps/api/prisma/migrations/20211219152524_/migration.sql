-- AlterTable
ALTER TABLE "Call911" ADD COLUMN     "postal" TEXT;

-- AlterTable
ALTER TABLE "TaxiCall" ADD COLUMN     "postal" TEXT;

-- AlterTable
ALTER TABLE "TowCall" ADD COLUMN     "postal" TEXT;
