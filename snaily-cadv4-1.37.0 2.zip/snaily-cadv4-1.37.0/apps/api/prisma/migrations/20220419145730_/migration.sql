-- AlterTable
ALTER TABLE "MiscCadSettings" ADD COLUMN     "boloWebhookId" TEXT,
ADD COLUMN     "panicButtonWebhookId" TEXT;
