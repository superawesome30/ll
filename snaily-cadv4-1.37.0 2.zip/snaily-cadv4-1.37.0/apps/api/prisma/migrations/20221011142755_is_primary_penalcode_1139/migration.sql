-- AlterTable
ALTER TABLE "PenalCode" ADD COLUMN     "isPrimary" BOOLEAN NOT NULL DEFAULT true;
