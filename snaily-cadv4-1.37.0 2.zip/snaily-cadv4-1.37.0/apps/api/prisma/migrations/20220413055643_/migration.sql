-- AlterTable
ALTER TABLE "MiscCadSettings" ADD COLUMN     "inactivityTimeout" INTEGER;
