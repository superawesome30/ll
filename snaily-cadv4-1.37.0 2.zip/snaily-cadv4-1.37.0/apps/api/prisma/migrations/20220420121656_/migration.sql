-- AlterTable
ALTER TABLE "DepartmentValue" ADD COLUMN     "isConfidential" BOOLEAN NOT NULL DEFAULT false;
