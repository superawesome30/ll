-- AlterTable
ALTER TABLE "EmsFdDeputy" ADD COLUMN     "incremental" INTEGER;

-- AlterTable
ALTER TABLE "Officer" ADD COLUMN     "incremental" INTEGER;
