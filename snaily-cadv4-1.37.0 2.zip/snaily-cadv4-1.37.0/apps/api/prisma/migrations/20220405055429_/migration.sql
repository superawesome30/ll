-- AlterTable
ALTER TABLE "Call911" ADD COLUMN     "caseNumber" SERIAL NOT NULL;
