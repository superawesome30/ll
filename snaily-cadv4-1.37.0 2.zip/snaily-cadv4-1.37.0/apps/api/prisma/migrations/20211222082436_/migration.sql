-- AlterTable
ALTER TABLE "MiscCadSettings" ADD COLUMN     "roleplayEnabled" BOOLEAN DEFAULT true;
