-- AlterTable
ALTER TABLE "User" ADD COLUMN     "lastDiscordSyncTimestamp" TIMESTAMP(3);
