-- AlterTable
ALTER TABLE "MiscCadSettings" ADD COLUMN     "activeDispatchersInactivityTimeout" INTEGER;
