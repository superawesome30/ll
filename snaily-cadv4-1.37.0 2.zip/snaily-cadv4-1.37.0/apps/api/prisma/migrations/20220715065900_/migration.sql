-- AlterTable
ALTER TABLE "Record" ALTER COLUMN "officerId" DROP NOT NULL;

-- AlterTable
ALTER TABLE "Warrant" ALTER COLUMN "officerId" DROP NOT NULL;
