-- AlterTable
ALTER TABLE "Citizen" ADD COLUMN     "occupation" TEXT;
