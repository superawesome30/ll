-- AlterTable
ALTER TABLE "Business" ADD COLUMN     "postal" VARCHAR(255);

-- AlterTable
ALTER TABLE "Citizen" ADD COLUMN     "postal" VARCHAR(255);
