-- AlterEnum
ALTER TYPE "DiscordWebhookType" ADD VALUE 'WARRANTS';
