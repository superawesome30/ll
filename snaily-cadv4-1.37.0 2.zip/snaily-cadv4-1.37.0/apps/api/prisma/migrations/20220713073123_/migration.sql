-- AlterTable
ALTER TABLE "RegisteredVehicle" ADD COLUMN     "appearance" TEXT;
