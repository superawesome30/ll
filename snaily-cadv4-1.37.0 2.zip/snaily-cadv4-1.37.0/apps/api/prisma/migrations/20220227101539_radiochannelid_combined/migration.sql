-- AlterTable
ALTER TABLE "CombinedLeoUnit" ADD COLUMN     "radioChannelId" TEXT;
