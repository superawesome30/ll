-- AlterTable
ALTER TABLE "UserSoundSettings" ADD COLUMN     "speech" BOOLEAN NOT NULL DEFAULT true;
