-- AlterTable
ALTER TABLE "UserSoundSettings" ADD COLUMN     "statusUpdate" BOOLEAN NOT NULL DEFAULT false;
