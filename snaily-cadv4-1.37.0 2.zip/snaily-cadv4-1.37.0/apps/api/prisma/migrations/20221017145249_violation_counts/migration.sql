-- AlterTable
ALTER TABLE "Violation" ADD COLUMN     "counts" INTEGER;
