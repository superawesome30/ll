-- AlterTable
ALTER TABLE "Citizen" ADD COLUMN     "additionalInfo" TEXT;
