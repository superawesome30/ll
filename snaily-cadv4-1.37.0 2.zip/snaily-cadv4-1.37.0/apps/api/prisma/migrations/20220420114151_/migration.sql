-- AlterTable
ALTER TABLE "UserSoundSettings" ADD COLUMN     "incomingCall" BOOLEAN NOT NULL DEFAULT false;
