-- AlterTable
ALTER TABLE "MiscCadSettings" ADD COLUMN     "call911WebhookId" TEXT,
ADD COLUMN     "statusesWebhookId" TEXT;
