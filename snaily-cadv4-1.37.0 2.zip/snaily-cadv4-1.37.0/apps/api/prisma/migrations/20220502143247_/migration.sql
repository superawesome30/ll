-- AlterTable
ALTER TABLE "CombinedLeoUnit" ADD COLUMN     "pairedUnitTemplate" TEXT;

-- AlterTable
ALTER TABLE "DivisionValue" ADD COLUMN     "pairedUnitTemplate" TEXT;
