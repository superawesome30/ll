-- AlterTable
ALTER TABLE "MiscCadSettings" ADD COLUMN     "activeWarrantsInactivityTimeout" INTEGER,
ADD COLUMN     "boloInactivityTimeout" INTEGER;
