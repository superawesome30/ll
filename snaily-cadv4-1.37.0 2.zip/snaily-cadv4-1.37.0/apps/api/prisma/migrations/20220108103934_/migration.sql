-- AlterTable
ALTER TABLE "MiscCadSettings" ADD COLUMN     "authScreenBgImageId" TEXT,
ADD COLUMN     "authScreenHeaderImageId" TEXT;
