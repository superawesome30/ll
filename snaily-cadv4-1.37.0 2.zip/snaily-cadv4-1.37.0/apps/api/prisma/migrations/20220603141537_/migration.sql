-- AlterTable
ALTER TABLE "TruckLog" ADD COLUMN     "notes" TEXT;
