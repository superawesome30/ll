-- AlterTable
ALTER TABLE "CombinedLeoUnit" ADD COLUMN     "callsign2" TEXT,
ADD COLUMN     "incremental" INTEGER;
