-- AlterTable
ALTER TABLE "MiscCadSettings" ADD COLUMN     "cadOGDescription" TEXT;
