-- AlterTable
ALTER TABLE "Citizen" ALTER COLUMN "userId" DROP NOT NULL;

-- AlterTable
ALTER TABLE "MedicalRecord" ALTER COLUMN "userId" DROP NOT NULL;
