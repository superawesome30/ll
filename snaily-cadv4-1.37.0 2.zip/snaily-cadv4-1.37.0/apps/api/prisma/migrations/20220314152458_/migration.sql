-- AlterEnum
ALTER TYPE "DriversLicenseCategoryType" ADD VALUE 'FIREARM';
