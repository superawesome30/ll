-- AlterTable
ALTER TABLE "EmsFdDeputy" ADD COLUMN     "position" TEXT;

-- AlterTable
ALTER TABLE "Officer" ADD COLUMN     "position" TEXT;
