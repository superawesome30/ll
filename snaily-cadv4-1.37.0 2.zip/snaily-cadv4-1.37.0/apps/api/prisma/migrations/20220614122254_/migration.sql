-- AlterTable
ALTER TABLE "Citizen" ADD COLUMN     "appearance" TEXT;
