-- AlterTable
ALTER TABLE "Value" ADD COLUMN     "isDisabled" BOOLEAN NOT NULL DEFAULT false;
