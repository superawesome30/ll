-- AlterTable
ALTER TABLE "MedicalRecord" ALTER COLUMN "type" DROP NOT NULL,
ALTER COLUMN "description" DROP NOT NULL;
