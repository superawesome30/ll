-- AlterTable
ALTER TABLE "Call911" ADD COLUMN     "isSignal100" BOOLEAN DEFAULT false;
