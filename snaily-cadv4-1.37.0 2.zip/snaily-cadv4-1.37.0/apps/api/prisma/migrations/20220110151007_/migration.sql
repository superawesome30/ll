-- AlterTable
ALTER TABLE "PenalCodeGroup" ADD COLUMN     "position" INTEGER;
