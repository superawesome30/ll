-- AlterTable
ALTER TABLE "QualificationValue" ADD COLUMN     "description" TEXT;

-- AlterTable
ALTER TABLE "Value" ADD COLUMN     "officerRankImageId" TEXT;
