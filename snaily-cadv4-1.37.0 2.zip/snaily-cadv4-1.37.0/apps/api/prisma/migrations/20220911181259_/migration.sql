-- AlterTable
ALTER TABLE "AssignedUnit" ADD COLUMN     "isPrimary" BOOLEAN DEFAULT false;
