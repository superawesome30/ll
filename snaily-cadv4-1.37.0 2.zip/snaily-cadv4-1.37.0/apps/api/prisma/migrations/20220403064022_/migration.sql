-- AlterTable
ALTER TABLE "MiscCadSettings" ADD COLUMN     "maxAssignmentsToCalls" INTEGER,
ADD COLUMN     "maxAssignmentsToIncidents" INTEGER;
