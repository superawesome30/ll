-- AlterTable
ALTER TABLE "UserSoundSettings" ADD COLUMN     "speechVoice" TEXT;
