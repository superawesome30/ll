-- AlterTable
ALTER TABLE "MiscCadSettings" ALTER COLUMN "pairedUnitTemplate" SET DEFAULT E'1A-{callsign1}';
