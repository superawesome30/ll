-- AlterTable
ALTER TABLE "LeoIncident" ADD COLUMN     "postal" TEXT;
