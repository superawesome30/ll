/*
  Warnings:

  - You are about to drop the column `position` on the `StatusValue` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "StatusValue" DROP COLUMN "position";
