-- AlterTable
ALTER TABLE "DriversLicenseCategoryValue" ADD COLUMN     "description" TEXT;
