-- AlterTable
ALTER TABLE "User" ADD COLUMN     "locale" TEXT;
