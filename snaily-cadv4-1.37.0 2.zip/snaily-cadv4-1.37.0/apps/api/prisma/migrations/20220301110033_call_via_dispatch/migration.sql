-- AlterTable
ALTER TABLE "Call911" ADD COLUMN     "viaDispatch" BOOLEAN DEFAULT false;
