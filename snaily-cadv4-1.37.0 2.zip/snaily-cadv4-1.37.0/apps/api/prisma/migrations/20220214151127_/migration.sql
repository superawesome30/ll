-- AlterTable
ALTER TABLE "MiscCadSettings" ADD COLUMN     "maxDepartmentsEachPerUser" INTEGER;
