-- AlterTable
ALTER TABLE "CallTypeValue" ALTER COLUMN "priority" SET DATA TYPE TEXT;
